    sap.ui.define([
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/routing/History",
        "sap/ui/core/routing/HashChanger",
        "sap/m/MessageToast"
    ], function (Controller, History,HashChanger, MessageToast) {
        "use strict";
        return Controller.extend("Quickstart.controller.Detail", {
            onInit: function () {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.getRoute("detail").attachPatternMatched(this._onObjectMatched, this);
            },
            _onObjectMatched: function (oEvent) {
                this.getView().bindElement({
                    path: "/" + window.decodeURIComponent(oEvent.getParameter("arguments").invoicePath)

                });
            },
            onNavBack: function () {
                        var oHistory = History.getInstance();
                        var sPreviousHash = oHistory.getPreviousHash();

                        if (sPreviousHash !== undefined) {
                            window.history.go(-1);
                        } else {
                            var oRouter = this.getOwnerComponent().getRouter();
                            oRouter.navTo("overview", {}, true);
                            window.location.reload();
                        }
                    },
                    onUpdate: function(oEvent) {
                                      var oView = this.getView();
                                        var oView = this.getView();
                                        var oModel = new sap.ui.model.odata.ODataModel("sap/opu/odata/SAP/ZBOOKS_UBB_MO_SRV");
                                        var mNewEntry = {};
                                        var ISBN = oView.byId("idIsbn").getValue();
                                        mNewEntry.ISBN = ISBN;
                                        var Author = oView.byId("idAuthor").getValue();
                                        mNewEntry.Author= Author.replace(/[""]+/g, '');
                                        var Title = oView.byId("idTitle").getValue();
                                        mNewEntry.Title = Title.replace(/[""]+/g, '');
                                        var Date = oView.byId("idDate").getValue();
                                        var Language = oView.byId("idLanguage").getValue();
                                        mNewEntry.Language  = Language.replace(/[""]+/g, '');
                                        var ABooks=oView.byId("idABooks").getValue();
                                        mNewEntry.ABooks=parseInt(ABooks);
                                        var TBooks = oView.byId("idTBooks").getValue();
                                        mNewEntry.TBooks = parseInt(TBooks);

                                    oModel.update("/BooksSet('"+ISBN+"')", mNewEntry, {
                                        method: "UPDATE",
                                        success: function(){
                                         MessageToast.show("Book has been updated successfully!");
                                         var oHistory = History.getInstance();
                                                         var sPreviousHash = oHistory.getPreviousHash();

                                                         if (sPreviousHash !== undefined) {
                                                                  window.history.go(-1);
                                                         } else {
                                                             var oRouter = this.getOwnerComponent().getRouter();
                                                             oRouter.navTo("overview", {}, true);
                                                         }
                                },
                                error: function() {
                                     MessageToast.show("ERROR");
                                }
                        });

                                  }
        });
    });