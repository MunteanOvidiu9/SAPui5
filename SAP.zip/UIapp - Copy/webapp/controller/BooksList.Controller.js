sap.ui.define([
   "sap/ui/core/mvc/Controller",
   "sap/ui/model/json/JSONModel",
   "sap/m/MessageToast",
   "sap/ui/model/Filter",
   "sap/ui/model/FilterOperator",
   "sap/ui/model/FilterType"

], function (Controller, JSONModel,MessageToast,Filter,FilterOperator,FilterType) {
   "use strict";

   return Controller.extend("Quickstart.controller.BooksList", {
      onInit : function () {
        var oViewModel = new JSONModel({
             });
            this.getView().setModel(oViewModel, "view");

      },
        onSearch(oEvent){
                                var aFilter = [];
                                var oList = this.getView().byId("BooksList");
                                var oBinding = oList.getBinding("items");
                                var title = this.byId("inputTitle").getValue();
                                var author = this.byId("inputAuthor").getValue();
                                var firstname = this.byId("inputFirstName").getValue();
                                var lastname = this.byId("inputLastName").getValue();

                                if (author) {
                                   aFilter.push(new Filter("Author", FilterOperator.EQ, author));
                               }
                                if (title) {
                                    aFilter.push(new Filter("Title", FilterOperator.EQ, title));
                               }
                                if (firstname) {
                                    aFilter.push(new Filter("Firstname", FilterOperator.EQ, firstname));
                               }
                               if (lastname) {
                                    aFilter.push(new Filter("Lastname", FilterOperator.EQ, lastname));
                                                }
                                oBinding.filter(aFilter);

                            },
   });
});