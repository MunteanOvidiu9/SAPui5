sap.ui.define([
   "sap/ui/core/mvc/Controller",
   "sap/ui/model/json/JSONModel",
   "sap/m/MessageToast",
   "sap/ui/model/Filter",
   	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, MessageToast, Filter, FilterOperator) {
   "use strict";

   return Controller.extend("Quickstart.controller.BooksList", {
      onInit : function () {
         var oViewModel = new JSONModel({
         });
         this.getView().setModel(oViewModel, "view");
      },
      handleDelete:function(oEvent){
      var sBookPath = oEvent.getParameter('listItem').getBindingContext().getPath();
      this.getView().getModel().remove(sBookPath,{
      success:function(){
                  MessageToast.show("Book has been removed");}
      });
      },
      onPress: function (oEvent) {
      		            var oItem = oEvent.getSource();
              			var oRouter = this.getOwnerComponent().getRouter();
              			oRouter.navTo("detail", {
                                          invoicePath: window.encodeURIComponent(oItem.getBindingContext().getPath().substr(1))
                          });
              		},
      onOpenNewWindow:function(){
          var oRouter = this.getOwnerComponent().getRouter();
                        			oRouter.navTo("AddBook");
      }

   });
});