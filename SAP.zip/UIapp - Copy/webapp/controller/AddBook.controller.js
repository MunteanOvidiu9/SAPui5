sap.ui.define([
   "sap/ui/core/mvc/Controller",
   "sap/ui/core/routing/History",
   "sap/ui/core/routing/HashChanger",
   "sap/m/MessageToast",
   "sap/ui/model/json/JSONModel"
], function (Controller, History, HashChanger,MessageToast,JSONModel) {
   "use strict";

   return Controller.extend("Quickstart.controller.AddBook", {
      onInit: function () {
         var oRouter = this.getOwnerComponent().getRouter();
         oRouter.getRoute("AddBook").attachPatternMatched(this._onObjectMatched, this);

      },
      _onObjectMatched: function (oEvent) {
         this.getView().bindElement({
            path: "/" + window.decodeURIComponent()

         });
      },
      onNavBack: function () {
                 var oHistory = History.getInstance();
                 var sPreviousHash = oHistory.getPreviousHash();

                 if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                 } else {
                    var oRouter = this.getOwnerComponent().getRouter();
                    oRouter.navTo("overview", {}, true);
                    window.location.reload();
                 }
              },
      onInsertProduct: function(oEvent) {
                  var oView = this.getView();
                    var oView = this.getView();
                    var oModel = new sap.ui.model.odata.ODataModel("sap/opu/odata/SAP/ZBOOKS_UBB_MO_SRV");
                    var mNewEntry = {};
                    console.log(oModel);
                    var ISBN = oView.byId("ISBN").getValue();
                    mNewEntry.ISBN = ISBN;
                    var Author = oView.byId("Author").getValue();
                    mNewEntry.Author= Author.replace(/[""]+/g, '');
                    var Title = oView.byId("Title").getValue();
                    mNewEntry.Title = Title.replace(/[""]+/g, '');
                    var Date = oView.byId("DP5").getDateValue();
                    var Language = oView.byId("Language").getSelectedKey();
                    mNewEntry.Language  = Language.replace(/[""]+/g, '');
                    var ABooks=oView.byId("Available").getValue();
                    mNewEntry.ABooks=parseInt(ABooks);
                    var TBooks = oView.byId("Total").getValue();
                    mNewEntry.TBooks = parseInt(TBooks);
                    MessageToast.show(mNewEntry);
                    console.log(mNewEntry);

                oModel.create("/BooksSet", mNewEntry, {
                    method: "POST",
                    success: function(){
                     MessageToast.show("Book added");
                var oHistory = History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();

                if (sPreviousHash !== undefined) {
                         window.history.go(-1);
                } else {
                    var oRouter = this.getOwnerComponent().getRouter();
                    oRouter.navTo("overview", {}, true);
                    window.location.reload();
                    reload();
                }
            },
            error: function() {
                 MessageToast.show("Error");
            }
    });

              }
   });
});