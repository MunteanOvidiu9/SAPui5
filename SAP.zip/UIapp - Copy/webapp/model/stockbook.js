sap.ui.define([], function () {
	"use strict";
	return {
		stockText: function (sStock) {
			var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (sStock<5){
			    return resourceBundle.getText("firstcase")
			}
			if (sStock<10 && sStock>=5){
            			    return resourceBundle.getText("secondcase")
            }
            if (sStock>=10){
            			    return resourceBundle.getText("thirdcase")
            }
		}
	};
});